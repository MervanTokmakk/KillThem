﻿namespace DungeonsOfDoom.Core.Characterss
{
    class Monster : Characters
    {
        public Monster(string name, int health) : base(name, health)
        {

        }
    }
}
