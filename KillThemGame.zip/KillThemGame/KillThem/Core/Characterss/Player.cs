﻿namespace DungeonsOfDoom.Core.Characterss
{
    class Player : Characters
    {
        public const int MaxHealth = 30;
        public Player() : base("Mervan", MaxHealth)
        {
            Health = MaxHealth;
            Knife = new List<Item>();
            Gun = new List<Item>();
            Pill = new List<Item>();
            Injection = new List<Item>();
        }

        public List <Item> Injection { get; set; }
        public List<Item> Pill { get; set; }    
        public List<Item> Knife { get; set; }
        public List<Item> Gun { get; set; }
        public int X { get; set; }
        public int Y { get; set; }




    }
}
