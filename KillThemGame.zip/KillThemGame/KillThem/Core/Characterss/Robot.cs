﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonsOfDoom.Core.Characterss
{
    class Robot : Monster
    {
        public Robot() : base("Robot", 15)
        {

        }

        public override void Attack(Characters opponent)
        {
            opponent.Health -= 5;
        }
    }
}
