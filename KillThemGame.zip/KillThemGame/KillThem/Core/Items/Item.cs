﻿using System.ComponentModel;

namespace DungeonsOfDoom.Core
{
    abstract class Item 
    {

        public Item(string name, int damage)
        {
            Name = name;
            Damage = damage;
        }
        public int Damage { get; set; }
        public string Name { get; set; }

       

    }
}
