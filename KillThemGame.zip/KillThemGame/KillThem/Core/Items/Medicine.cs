﻿using DungeonsOfDoom.Core.Characterss;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace DungeonsOfDoom.Core
{
    class Medicine : Item
    {
        public Medicine(string name, int damage) : base(name, damage)
        {
            
        }

        public virtual void Life(Player player)
        {
          
        }
    }

    // subklass
    class Pill : Medicine
    {
        public Pill() : base("Pill", 10)
        {

        }

        public override void Life(Player player)
        {
            player.Health += 10;
        }
    }
    // subklass
    class Injection : Medicine
    {
        public Injection() : base("Injection", 15)
        {

        }

        public override void Life(Player player)
        {
            player.Health += 15;
            
        }
    }
}
