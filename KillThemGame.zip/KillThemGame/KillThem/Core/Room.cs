﻿using DungeonsOfDoom.Core.Characterss;

namespace DungeonsOfDoom.Core
{
    class Room
    {
        public Monster MonsterInRoom { get; set; }
        public Item ItemInRoom { get; set; }
      
    }
}
