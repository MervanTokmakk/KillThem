﻿using DungeonsOfDoom.Core;
using DungeonsOfDoom.Core.Characterss;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics.Metrics;
using System.Text;

namespace DungeonsOfDoom
{

    class Program
    {
        Room[,] rooms;
        Player player;

        static void Main(string[] args)
        {
            Program program = new Program();
            program.Play();
        }

        public void Play()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.CursorVisible = false;

            player = new Player();
            CreateRooms();

            do
            {
                Console.Clear();
                DisplayRooms();
                DisplayStats();
                if (AskForMovement())
                {
                    ExploreRoom();
                }
            } while (player.IsAlive);

            GameOver();
        }

        void CreateRooms()
        {
            rooms = new Room[20, 5];
            for (int y = 0; y < rooms.GetLength(1); y++)
            {
                for (int x = 0; x < rooms.GetLength(0); x++)
                {
                    rooms[x, y] = new Room();

                    int spawnChance = Random.Shared.Next(1, 100 + 1);
                    if (spawnChance < 10)
                        rooms[x, y].MonsterInRoom = new Ghost();
                    else if (spawnChance < 15)
                        rooms[x, y].MonsterInRoom = new Robot();
                    else if (spawnChance < 20)
                        rooms[x, y].ItemInRoom = new Knife();
                    else if (spawnChance < 25)
                        rooms[x, y].ItemInRoom = new Gun();
                    else if (spawnChance < 30)
                        rooms[x, y].ItemInRoom = new Pill();
                    else if (spawnChance < 35)
                        rooms[x, y].ItemInRoom = new Injection();
                }
            }
        }

        void DisplayRooms()
        {
            for (int y = 0; y < rooms.GetLength(1); y++)
            {
                for (int x = 0; x < rooms.GetLength(0); x++)
                {
                    Room room = rooms[x, y];
                    if (player.X == x && player.Y == y)
                        Console.Write(player.Health >= Player.MaxHealth / 2 ? "🙂" : "😲");
                    else if (room.MonsterInRoom is Robot)
                        Console.Write("🤖");
                    else if (room.MonsterInRoom is Ghost)
                        Console.Write("👻");
                    else if (room.MonsterInRoom != null)
                        Console.Write("😈");
                    else if (room.ItemInRoom != null)
                        Console.Write("📦");
                    else
                        Console.Write("🔹");
                }
                Console.WriteLine();
            }
        }

        void DisplayStats()
        {
            Console.WriteLine($"❤️{player.Health}/{Player.MaxHealth}");
            Console.WriteLine($"🗡{player.Knife.Count}");
            Console.WriteLine($"🔫{player.Gun.Count}");
            Console.WriteLine($"💊{player.Pill.Count} Press 'P' to refill 10hp");
            Console.WriteLine($"💉{player.Injection.Count} Press 'I'  to refill 15hp");
        }

        bool AskForMovement()
        {
            int newX = player.X;
            int newY = player.Y;
            bool isValidKey = true;

            ConsoleKeyInfo keyInfo = Console.ReadKey();
            switch (keyInfo.Key)
            {
                case ConsoleKey.RightArrow: newX++; break;
                case ConsoleKey.LeftArrow: newX--; break;
                case ConsoleKey.UpArrow: newY--; break;
                case ConsoleKey.DownArrow: newY++; break;
                case ConsoleKey.P:
                    TakePill();
                    break;
                case ConsoleKey.I:
                    TakeInjection();
                    break;
                default: isValidKey = false; break;
            }

            if (isValidKey &&
                newX >= 0 && newX < rooms.GetLength(0) &&
                newY >= 0 && newY < rooms.GetLength(1))
            {
                player.X = newX;
                player.Y = newY;
                return true;
            }
            return false;
        }

        private void TakeInjection()
        {
            if (player.Health < 30)
            {
                for (int i = 0; i < player.Injection.Count; i++)
                {
                    if (player.Injection[i] is Medicine)
                    {
                        player.Injection.RemoveAt(i);
                        Injection injection = new Injection();
                        int healthToAdd = Math.Min(30 - player.Health, injection.Damage);
                        player.Health += healthToAdd;
                        break;

                        //player.Injection.RemoveAt(i);
                        //Injection injection = new Injection();
                        //int healthToAdd = Math.Min(30 - player.Health, injection.Damage);
                        //player.Health += healthToAdd;
                        //break;
                    }
                    else
                        break;
                }
            }
        }

        private void TakePill()
        {

            if (player.Health < 30)
            {
                for (int i = 0; i < player.Pill.Count; i++)
                {
                    if (player.Pill[i] is Medicine)
                    {
                        player.Pill.RemoveAt(i);
                        Pill pill = new Pill();
                        pill.Life(player);
                        break;

                        //player.Pill.RemoveAt(i);
                        //Pill pill = new Pill();
                        //int healthToAdd = Math.Min(30 - player.Health, pill.Damage);
                        //player.Health += healthToAdd;
                        //break;
                    }
                }
            }
        }   

        private void ExploreRoom()
        {
            Room room = rooms[player.X, player.Y];
            if (room.ItemInRoom != null)
            {
                if (room.ItemInRoom.Name == "Knife")
                {
                    player.Knife.Add(room.ItemInRoom);
                }
                else if (room.ItemInRoom.Name == "Gun")
                {
                    player.Gun.Add(room.ItemInRoom);
                }
                else if (room.ItemInRoom.Name == "Pill")
                {
                    player.Pill.Add(room.ItemInRoom);
                }
                else if (room.ItemInRoom.Name == "Injection")
                {
                    player.Injection.Add(room.ItemInRoom);
                }
                room.ItemInRoom = null;
            }
            if (room.MonsterInRoom != null)
            {
                player.Attack(room.MonsterInRoom);
                if (room.MonsterInRoom.IsAlive)
                {
                    room.MonsterInRoom.Attack(player);
                }
                else
                {
                    room.MonsterInRoom = null;
                }
                if (player.Knife.Count > 0)
                {
                    player.Knife.RemoveAt(0);
                    room.MonsterInRoom = null;
                }
                else if (player.Gun.Count > 0)
                {
                    player.Gun.RemoveAt(0);
                    room.MonsterInRoom = null;
                }
            }
        }

        void GameOver()
        {
            Console.Clear();
            Console.WriteLine("Game over...");
            Console.ReadKey();
            Play();
        }
    }
}
